"""`kedro_viz.data_access` provides an interface to save and load data for viz backend."""
from .managers import DataAccessManager

data_access_manager = DataAccessManager()
