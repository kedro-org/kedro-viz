"""`kedro_viz.api` defines the FastAPI app to serve Kedro data."""
