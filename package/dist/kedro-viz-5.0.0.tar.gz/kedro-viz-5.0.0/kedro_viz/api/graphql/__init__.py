"""`kedro_viz.api.graphql` defines the GraphQL API."""
