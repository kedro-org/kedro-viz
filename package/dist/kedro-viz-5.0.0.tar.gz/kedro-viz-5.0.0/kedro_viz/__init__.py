"""Kedro plugin for visualising a Kedro pipeline"""

__version__ = "5.0.0"
